const { getQuery, type, findQuery, update, remove, save } = require("../../core/model");

exports.userEntity = {
    userId: type.number,
    name: type.string,
    email: type.string,
    password_hash: type.string,
    role: type.enum(['Admin', 'Client', 'Worker']),
    createdAt: type.date,
    updatedAt: type.date
};

// Obtener todos los usuarios
module.exports.getAllUsers = async () => await getQuery("SELECT * FROM USERS", [], this.userEntity);

// Obtener un usuario por su ID
module.exports.getUserByUserId = async userId => await getQuery('SELECT * FROM USERS WHERE user_id = ?', [userId], this.userEntity);

module.exports.saveUser = async (user) => {
    if (!user.email) {
        throw new Error("El email del usuario no puede estar vacío");
    }

    if (!user.passwordHash) {
        throw new Error("La contraseña del usuario no puede estar vacía");
    }

    const whereObj = { email: user.email };
    
    // Verifica que `password_hash` esté presente en `dataObj`
    const dataObj = {
        name: user.name,
        email: user.email,
        password_hash: user.passwordHash,  // Aquí debe estar el hash de la contraseña
        role: user.role
    };

    console.log("Datos que se guardan:", dataObj);  // Log para verificar que se está pasando el hash correcto

    // Usamos la función save para insertar o actualizar
    return await save('USERS', dataObj, whereObj, this.userEntity);
};

// Actualizar un usuario en la base de datos por su ID
module.exports.updateUserById = async (userId, updatedUserData) => {
    const table = 'USERS';  // Tabla donde se encuentra el usuario
    const whereObj = { userId };  // Condición para identificar al usuario por su ID
    
    // Llamar a la función de actualización
    return await update(table, updatedUserData, whereObj, this.userEntity);
};

// Obtener un usuario por su email
module.exports.getUserByEmail = async (email) => {
    return await getQuery('SELECT * FROM USERS WHERE email = ?', [email]);
};