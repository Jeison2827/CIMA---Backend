const { getAllUsers, getUserByUserId, saveUser, getUserByEmail,updateUserById} = require("./user-model");

// Obtener todos los usuarios
module.exports.getAllUsers = async () => await getAllUsers();

// Obtener un usuario por su ID
module.exports.getUserByUserId = async (userId) => await getUserByUserId(userId);

// Guardar un usuario (insertar o actualizar)
module.exports.saveUser = async (user) => {
    try {
        return await saveUser(user);
    } catch (error) {
        throw new Error('Error al guardar el usuario: ' + error.message);
    }
};
// Actualizar un usuario por su ID
module.exports.updateUserById = async (userId, updatedUserData) => {
    try {
        // Llama al método correcto en el modelo para actualizar el usuario
        return await updateUserById(userId, updatedUserData);
    } catch (error) {
        throw new Error('Error al actualizar el usuario: ' + error.message);
    }
};
module.exports.getUserByEmail = async  (email) => await getUserByEmail(email);

