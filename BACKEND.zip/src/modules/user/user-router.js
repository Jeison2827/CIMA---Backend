const express = require('express');
const router = express.Router();
const { getAllUsers, getUserByUserId, saveUser, getUserByEmail, UserById,updateUserById } = require('./user-service');
const yup = require('yup');
const { auth } = require('../../util/router-util');
const bcrypt = require('bcryptjs');

// Actualizar un usuario por ID
router.put('/:id', auth, async (req, res) => {
    try {
        const userId = req.params.id;
        const { name, email, password, role } = req.body;

        // Generar el objeto con los campos que se van a actualizar
        const updatedUserData = {};
        if (name) updatedUserData.name = name;
        if (email) updatedUserData.email = email;
        if (password) {
            // Hash de la nueva contraseña (si se proporciona)
            updatedUserData.passwordHash = await bcrypt.hash(password, 10);
        }
        if (role) updatedUserData.role = role;

        // Llamar al servicio para actualizar el usuario
        const result = await updateUserById(userId, updatedUserData);

        if (result) {
            res.status(200).json({ message: 'Usuario actualizado exitosamente', user: updatedUserData });
        } else {
            res.status(404).json({ message: 'Usuario no encontrado' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Error al actualizar el usuario', error: error.message });
    }
});

// Ruta para registrar un usuario
router.post('/register', async (req, res) => {
    const { name, email, password, role } = req.body;
    try {
        // Validación de los datos de entrada
        yup.object({
            name: yup.string().required(),
            email: yup.string().email().required(),
            password: yup.string().required(),
            role: yup.string().oneOf(['Admin', 'Client', 'Worker']).required() // Validación del rol
        }).validateSync(req.body);

        // Hash de la contraseña
        const passwordHash = await bcrypt.hash(password, 10); // 10 es el número de salt rounds

        // Crear el objeto del nuevo usuario
        const newUser = {
            name,
            email,
            passwordHash:passwordHash, // Almacena la contraseña hasheada
            role
        };

        // Guardar el usuario en la base de datos
        let a=await saveUser(newUser);
        res.status(201).json({ message: 'Usuario registrado exitosamente', newUser,a });
    } catch (error) {
        res.status(400).json({ error: error.message, message: 'Error en el registro' });
    }
});
// Ruta de login con email y contraseña
router.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        // Validar que el email y la contraseña estén presentes
        yup.object({
            email: yup.string().email().required(),
            password: yup.string().required()
        }).validateSync(req.body);

        // Obtener el usuario por su email
        const user = await getUserByEmail(email);
        if (!user) {
            return res.status(401).json({ error: 'Usuario no encontrado' });
        }

        // Verificar la contraseña con bcrypt
        const isPasswordValid = await bcrypt.compare(password, user.passwordHash);
        if (!isPasswordValid) {
            return res.status(401).json({ error: 'Contraseña incorrecta' });
        }

        // Si la autenticación es exitosa, crear el JWT
        const claims = {
            sub: user.userId,
            email: user.email
        };
        const jwt = require('njwt').create(claims, 'secret', 'HS256');
        jwt.setExpiration(new Date().getTime() + 294537600000); // 1 año de expiración

        // Enviar el token y los datos del usuario al cliente
        res.json({ accessToken: jwt.compact(), user });
    } catch (error) {
        res.status(401).json({ error: error.message, message: 'Error en la autenticación' });
    }
});

// Obtener un usuario por ID con autenticación y fechas estandarizadas
router.get('/:id', auth, async (req, res) => {
    try {
        const user = await getUserByUserId(req.params.id);

        // Estandarizar las fechas en un formato más limpio
        if (user.createdAt) {
            user.createdAt = new Date(user.createdAt).toLocaleString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        }
        if (user.dAt) {
            user.dAt = new Date(user.dAt).toLocaleString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        }

        // Devolver los datos del usuario
        res.status(200).json(user);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});


// Obtener todos los usuarios (si es necesario agregar esta funcionalidad)
router.get('/', async (req, res) => {
    try {
        const users = await getAllUsers();
        res.status(200).json(users);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;
