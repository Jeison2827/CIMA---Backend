const { getQuery, update, remove, save, type } = require('../../core/model');

// Definir la entidad del cliente
exports.clientEntity = {
    clientId: type.number,
    userId: type.number,
    contactInfo: type.string,
    address: type.string,
    additionalInfo: type.string,
    createdAt: type.date,
    updatedAt: type.date
};  
module.exports.saveClient = async (client) => {
    if (!client.userId) {
        throw new Error("El userId del cliente no puede estar vacío");
    }

    if (!client.contactInfo) {
        throw new Error("La información de contacto no puede estar vacía");
    }

    const whereObj = { userId: client.userId };

    const dataObj = {
        userId: client.userId,
        contactInfo: client.contactInfo,
        address: client.address,
        additionalInfo: client.additionalInfo
    };

    try {
        const result = await save('CLIENTS', dataObj, whereObj, this.clientEntity);

        // Verificar que el clientId se esté devolviendo correctamente
        if (!result || !result.clientId) {
            throw new Error('El cliente no fue creado correctamente.');
        }

        return result; // Devolver el cliente con el clientId
    } catch (error) {
        console.error("Error en la operación de guardar cliente:", error.message);
        throw new Error('Error al guardar el cliente: ' + error.message);
    }
};


// Actualizar un cliente por su ID
module.exports.updateClientById = async (clientId, updatedData) => {
    try {
        // Actualizar el cliente en la base de datos
        const result = await update('CLIENTS', updatedData, { client_id: clientId }, this.clientEntity);

        if (!result) {
            throw new Error('No se pudo actualizar el cliente.');
        }

        return result;
    } catch (error) {
        throw new Error('Error al actualizar el cliente: ' + error.message);
    }
};

// Obtener un cliente por su ID
module.exports.getClientById = async (clientId) => {
    try {
        const client = await getQuery('SELECT * FROM CLIENTS WHERE client_id = ?', [clientId], this.clientEntity);

        if (!client) {
            throw new Error('Cliente no encontrado.');
        }

        return client;
    } catch (error) {
        throw new Error('Error al obtener el cliente: ' + error.message);
    }
};

// Eliminar un cliente por su ID
module.exports.deleteClientById = async (clientId) => {
    try {
        const result = await remove('CLIENTS', { client_id: clientId }, this.clientEntity);

        if (!result) {
            throw new Error('No se pudo eliminar el cliente.');
        }

        return result;
    } catch (error) {
        throw new Error('Error al eliminar el cliente: ' + error.message);
    }
};
