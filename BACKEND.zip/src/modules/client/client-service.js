const { getClientById, saveClient, updateClientById, deleteClientById } = require('./client-model');

// Obtener un cliente por su ID
module.exports.getClientById = async (clientId) => {
    try {
        const client = await getClientById(clientId);

        if (!client) {
            throw new Error('Cliente no encontrado.');
        }

        return client;
    } catch (error) {
        throw new Error('Error al obtener el cliente: ' + error.message);
    }
};
module.exports.saveClient = async (client) => {
    try {
        // Llamar al modelo para crear el cliente
        const newClient = await saveClient(client);

        // Verificar que el cliente ha sido insertado correctamente y que contiene un clientId
        if (!newClient || !newClient.clientId) {
            throw new Error('El cliente no fue creado correctamente.');
        }

        return newClient; // Devolver el cliente con el clientId
    } catch (error) {
        throw new Error('Error al guardar el cliente: ' + error.message);
    }
};

// Actualizar un cliente por su ID
module.exports.updateClientById = async (clientId, updatedClientData) => {
    try {
        const updatedClient = await updateClientById(clientId, updatedClientData);

        if (!updatedClient) {
            throw new Error('No se pudo actualizar el cliente.');
        }

        return updatedClient;
    } catch (error) {
        throw new Error('Error al actualizar el cliente: ' + error.message);
    }
};

// Eliminar un cliente por su ID
module.exports.deleteClientById = async (clientId) => {
    try {
        const result = await deleteClientById(clientId);

        if (!result) {
            throw new Error('No se pudo eliminar el cliente.');
        }

        return result;
    } catch (error) {
        throw new Error('Error al eliminar el cliente: ' + error.message);
    }
};
