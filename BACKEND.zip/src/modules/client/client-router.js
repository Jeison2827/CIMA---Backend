const express = require('express');
const router = express.Router();
const { getClientById, saveClient, updateClientById, deleteClientById } = require('./client-service');
const yup = require('yup');
const { auth } = require('../../util/router-util');

// Crear un nuevo cliente

// Crear un nuevo cliente
router.post('/', auth, async (req, res) => {
    try {
        const { userId, contactInfo, address, additionalInfo } = req.body;

        // Llamar al servicio para guardar el cliente
        const newClient = await saveClient({ userId, contactInfo, address, additionalInfo });

        // Enviar la respuesta con el cliente y el clientId
        res.status(201).json({ message: 'Cliente creado exitosamente', client: newClient });
    } catch (error) {
        res.status(500).json({ message: 'Error al crear el cliente', error: error.message });
    }
});


// Actualizar un cliente por ID
router.put('/:id', auth, async (req, res) => {
    try {
        const clientId = req.params.id;

        // Validación de los datos de entrada
        const schema = yup.object().shape({
            userId: yup.number().nullable(),
            contactInfo: yup.string().nullable(),
            address: yup.string().nullable(),
            additionalInfo: yup.string().nullable(),
        });

        await schema.validate(req.body);

        const { userId, contactInfo, address, additionalInfo } = req.body;

        // Verificar si hay datos para actualizar
        const updatedClientData = {};
        if (userId) updatedClientData.userId = userId;
        if (contactInfo) updatedClientData.contactInfo = contactInfo;
        if (address) updatedClientData.address = address;
        if (additionalInfo) updatedClientData.additionalInfo = additionalInfo;

        // Llamar al servicio para actualizar el cliente
        const updatedClient = await updateClientById(clientId, updatedClientData);

        if (!updatedClient) {
            return res.status(404).json({ message: 'Cliente no encontrado' });
        }

        res.status(200).json({ message: 'Cliente actualizado exitosamente', client: updatedClient });
    } catch (error) {
        res.status(500).json({ message: 'Error al actualizar el cliente', error: error.message });
    }
});

// Obtener un cliente por ID
router.get('/:id', auth, async (req, res) => {
    try {
        const clientId = req.params.id;

        // Llamar al servicio para obtener el cliente
        const client = await getClientById(clientId);

        if (!client) {
            return res.status(404).json({ message: 'Cliente no encontrado' });
        }

        res.status(200).json(client);
    } catch (error) {
        res.status(500).json({ message: 'Error al obtener el cliente', error: error.message });
    }
});

// Eliminar un cliente por ID
router.delete('/:id', auth, async (req, res) => {
    try {
        const clientId = req.params.id;

        // Llamar al servicio para eliminar el cliente
        await deleteClientById(clientId);
        res.status(200).json({ message: 'Cliente eliminado exitosamente' });
    } catch (error) {
        res.status(500).json({ message: 'Error al eliminar el cliente', error: error.message });
    }
});

module.exports = router;
