const express = require('express');
const router = express.Router();
const {getItem}= require("../../core/model")

router.get('/login', async (req, res) => {
    const results = await getItem()
    return res.status(200).json({
        message: 'Login',
        res:results
    });
})

module.exports = router;