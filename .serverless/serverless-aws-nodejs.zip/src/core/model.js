const mysql = require('serverless-mysql')({
    config: {
        host: process.env.DB_HOST,
        database: process.env.DB_NAME,
        user: process.env.DB_USER,
        password: process.env.DB_PASS
    }
})

exports.getItem = ()=>{
    /*
    const host= process.env.DB_HOST
    const database= process.env.DB_NAME
    const user=process.env.DB_USER
    const password= process.env.DB_PASS
    return host+database +user+ password
    */
       return new Promise((resolve, reject)=>{
         mysql.query('SELECT * FROM USERS', (err, results)=>{
           
            if(err){
                return reject(err)
            }
            return resolve(results)
        })
    })
}

